package com.example.aula4;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.Nullable;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        TextView frase = findViewById(R.id.textView);
        Button ingles = findViewById(R.id.button2);
        Button portugues = findViewById(R.id.button3);

        ingles.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                frase.setText("No PEN, no gain");

            }
        });
        portugues.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                frase.setText("Sem dor não há ganho");
            }
        });
    }
}

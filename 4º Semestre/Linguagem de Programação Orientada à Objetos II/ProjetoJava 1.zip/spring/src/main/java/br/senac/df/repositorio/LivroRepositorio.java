package br.senac.df.repositorio;

import org.springframework.data.jpa.repository.JpaRepository;

import br.senac.df.model.Livro;

@Repository
public interface LivroRepositorio extends JpaRepository <Livro, Integer> { 


}


package br.senac.df.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.senac.df.repositorio.LivroRepositorio;

@Service
public class LivroService {
	@Autowired
	LivroRepositorio livroRepositorio;
	
	public List<Livro> livro getAllLivro(){
		List<Livro> livro = new ArrayList<Livro>();
		livroRepositorio.findAll().forEach(livro -> livro.add(livro1));
		return livro;
	}
	public Livro getLivroById(int id) {
		return livroRepositorio.findById(id).get();
	}
	public void addLivro(livro livro) {
		livroRepositorio.save(livro);
	}
	public void updateLivro(livro livro) {
		livroRepositorio.save(livro);
	}
	public void deletLivro(int id) {
		livroRepositorio.deletById(id);;
	}
}



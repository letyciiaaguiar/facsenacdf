<?php

define ('HOST','localhost');
define( 'USER','root');
define( 'PASS', '');
define ('BASE', 'cadastro');

$conn = new mysqli(HOST,USER,PASS,BASE,3307);

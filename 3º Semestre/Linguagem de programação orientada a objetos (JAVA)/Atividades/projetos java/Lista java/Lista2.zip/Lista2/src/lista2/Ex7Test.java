package lista2;

public class Ex7Test {
    public static void main(String[] args) {
        double[] notas = {6.0, 7.5, 8.0, 5.0, 9.0, 6.5, 7.0, 8.5, 7.2, 6.8, 9.5, 5.5, 6.1, 7.3, 8.4};
        double media = Ex7.calcularMedia(notas);
        System.out.println("Média geral: " + media);
    }
}

package lista2;

public class Ex10Test {
    public static void main(String[] args) {
        int[] vetor = {1, 5, 3, 7, 5, 2, 3, 9, 10, 1};
        Ex10.verificarDuplicatas(vetor);
    }
}

package vetor;

public class Ex2Test {
	public static void main(String args[]) {
		Ex2 obj;
		obj = new Ex2();
		obj.leValores();
	}
}

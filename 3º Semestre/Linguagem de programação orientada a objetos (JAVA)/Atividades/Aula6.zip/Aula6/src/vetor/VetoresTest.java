package vetor;

import java.util.Scanner;
public class VetoresTest {
	public static void main(String args[]) {
		Scanner input;
		input= new Scanner(System.in);
		Vetores obj;
		obj = new  Vetores();
		System.out.print("Quantos valores deseja armazenar?");
		int qtd= input.nextInt();
		int vetorAux[]= obj.createVetor(qtd, input);
		obj.imprimeVetor(vetorAux);
		
		
		int maior= obj.maiorElemento(vetorAux);
		int menor= obj.menorElemento(vetorAux);
		System.out.println("O maior elemento é:"+ maior);
		System.out.println("O menor elemento é:"+ menor);
	}//fim main
}

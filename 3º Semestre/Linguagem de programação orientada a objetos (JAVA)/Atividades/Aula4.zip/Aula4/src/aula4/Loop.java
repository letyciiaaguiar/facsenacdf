package aula4;

import java.util.Scanner;
public class Loop {

	public void imprimirValores(int qtd) 
	{
		int i;
		for(i=1; i <=qtd; i++) {
			System.out.println("Numero:"+i);
		}//FIM FOR
	}//fim metodo
	
	public void contar(int contador, Scanner entrada) {
		int repetiu=0;
		while(contador !=0) 
		{
			repetiu=repetiu +1; // repetiu++
			System.out.println("Repetindo:"+repetiu);
			System.out.print("Digite 0 para parar ou qualquer valor"
					+ " para continuar:");
			contador= entrada.nextInt();
		}//fim while
	}//fim metodo  contar
	
	public void contaMais(int contador) {
		for (int i = 1; i <= contador; i++) {
			System.out.println("repetiu:"+i);
		}//fim for
	}
	public void core(Scanner input) {
		while(true) 
		{
			System.out.print("Repete quantas vezes?");
			int valor= input.nextInt();
			if(valor <=0) {
				break;
			}
			this.contaMais(valor);
			System.out.println("*****Finalizando impressao****");
		}//FIM while
	}//fim metodo core
	
	
	public void exemploDo(Scanner input) 
	{
		int v1=0;
		do {
			System.out.print("Digite um valor entre 1 e 10:");
			v1= input.nextInt();
		}while(v1 < 1 || v1 >10);
		System.out.println("Qual o valor final de v1?"+v1);
	}
	
	public void pares(Scanner input) {
		System.out.println("Digite um valor: ");
		int num = input.nextInt();
		int pares = 0;
		for (int i = 1; i <= num; i++) {
			if (i % 2 == 0 && i > 10) {
				pares += 1;
			}
		}
		System.out.println("Foram encontrados " + pares + 
				" números pares.");
	}
	
	
}//fim class

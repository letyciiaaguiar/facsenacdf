package aula4;
import java.util.Scanner;
public class LoopTest {
	public static void main(String args[]) 
	{
		Loop obj;
		obj= new Loop();
		Scanner entrada;
		entrada= new Scanner(System.in);
		//System.out.print("Digite o número de repetições:");
		//int number= entrada.nextInt();
		//obj.imprimirValores(number);
		//obj.contar(1, entrada);
		//obj.core(entrada);
		obj.pares(entrada);
		
		
		
		
		entrada.close();
	}//fim main
}//fim class

package encapsulamento;

import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;

public class ContaBancaria {
	private String titular;
	private double saldo;
	private List<String> historico;

	protected ContaBancaria(String titular, double saldo) {
		Scanner input = new Scanner(System.in);
		this.titular = titular;
		this.historico= new ArrayList<String>();
		if (saldo < 0) {
			System.out.println("Você digitou um saldo negativo? deseja alterar" + " o saldo? digite [s/n]:");
			if (input.next().toLowerCase().equals("s")) {
				System.out.print("Digite o novo saldo:");
				saldo = input.nextDouble();
			} // fim if
			this.saldo = saldo < 0 ? 0 : saldo;

		} // fim if
		else {
			this.saldo = saldo;
		} // fim else
	}// fim do construtor

	public void setTitular(String novoTitular) {
		this.titular = novoTitular;
	}

	public String getTitular() {
		return this.titular;
	}
	

	public List<String> getHistorico() {
		return historico;
	}

	public void setHistorico(List<String> historico) {
		this.historico = historico;
	}

	public double getSaldo() {
		return saldo;
	}

	public void setSaldo(double novoSaldo) {
		this.saldo = novoSaldo;
	}

	public void depositar(double novoDeposito) {
		if (novoDeposito <= 0) {
			System.out.println("Valor inválido!");
		} else {
			this.saldo = this.saldo + novoDeposito;
			historico.add("Depósito no valor de "+ novoDeposito);
			System.out.println("Depósito no valor de " + novoDeposito + 
					" feito com sucesso!");
		}
	}//fim depositar
	public void sacar(double valorSaque) {
		if(valorSaque <= 0) {
			System.out.println("O valor digitado não é o esperado!!");
		}
		else if(valorSaque > this.saldo) {
			System.out.println("Saldo insuficiente!!");
		}
		else {
			this.saldo= this.saldo - valorSaque;
			historico.add("Saque no valor de "+ valorSaque);
			System.out.println("Saque no valor de " + valorSaque + 
					" feito com sucesso!");
		}
	}//fim sacar
}// fim class

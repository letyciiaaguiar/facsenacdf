package pack1;

public class Visibilidade {

	public void imprimirPublic() {
		System.out.println("Imprimindo método public!!!");
	}
	
	protected void imprimirProtected() {
		System.out.println("Imprimindo método protected!!");
	
	}
	
	private void imprimirPrivate() {
		System.out.println("Imprimindo método private!!");
	}
}

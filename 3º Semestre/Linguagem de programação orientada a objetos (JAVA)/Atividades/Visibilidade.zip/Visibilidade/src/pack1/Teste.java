package pack1;

public class Teste {
	public static void main(String args[]) {
		Visibilidade obj = new Visibilidade();
		obj.imprimirPublic();
		obj.imprimirProtected();
	
	}
}

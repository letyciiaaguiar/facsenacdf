package pack2;

import java.util.Scanner;

import pack1.Visibilidade;
public class Teste2 {
	public static void main(String args[]) {
		Visibilidade obj = new Visibilidade();
		obj.imprimirPublic();
		
	}
}
